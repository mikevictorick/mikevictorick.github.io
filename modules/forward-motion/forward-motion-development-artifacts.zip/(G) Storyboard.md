# (G) Storyboard — From Frustration to Forward Motion

Version 0.6 · October 7, 2026 · Approved presentation and meeting-scene direction

## Experience

A district-branded browser course framed as an in-person meeting with a fictional educator. The three main tasks produce an opening response, a concern summary, and a follow-up plan. The course has twelve main screens, with overlays, branching inquiry turns, response assembly, and a repair loop inside them. The 15-minute duration remains a target requiring pilot timing.

All dialogue is text-accessible. Six wide Maya/room scene states are integrated; ElevenLabs audio remains pending. No drag gesture, microphone, timer, or runtime AI evaluator is required.

## Screen 01 — The concern

Maya describes recurring system failure, lost planning time, prior tickets, and feeling unheard. The learner enters the fictional Lake Dallas HS meeting. The opening title is a wide room scene with Maya on the right. Enter the meeting reveals her concern on a dialogue layer; Prepare my response advances to role orientation. Previous can return to the title. The presentation position saves locally.

## Screen 02 — Your role

The learner is a district leader supporting implementation. Use a distinct two-column briefing slide: the assignment on the left, Tuesday 10 a.m. authority and constraints on the right. A support-history layer provides context. Introduce the three work products: opening, concern notebook, and support plan. State that all scenario details are fictional and task work saves locally in this browser. Learners should use fictional content rather than real personal details.

## Screen 03 — Response strategy

Use a presentation master with three numbered click-to-reveal moves and a large example panel. Each move gains a Viewed state; exploration does not affect the assessment. Show Acknowledge → Clarify → Commit. A Strategy overlay remains available throughout practice. Recognition precedes explanation; inquiry identifies the impact; commitment names an action within authority and a dependable update.

## Screen 04 — Build your opening

**Presentation:** Three states: Listen, Arrange, Deliver. Listen overlays selectable words on the wide meeting scene. Arrange opens a paper work layer over the dimmed room, pairing a four-clause bank page with the ordered response; More clauses reveals the second bank page. Deliver previews the response beside Maya. Wording refinement opens a focused layer. Next advances through states before committing; Previous reverses a state.

**Inputs:** Four selectable phrases from Maya’s concern and eight short clauses.

**Actions:** Mark details, drag clauses into the response, drag existing clauses to reorder, or add/remove clauses and use Move up/down buttons. Dropping onto a clause inserts at that position; dropping into blank response space appends. Optionally edit the wording. Edited wording requires explicit self-review before Say this.

**Authored clauses:** recognition, prior effort, planning-time impact, invitation, rollout explanation, guidance reminder, guarantee of resolution today, and immediate ticket-number request.

**Strong component pattern:** mark prior effort and impact; assemble recognition, prior effort, and impact before the invitation; exclude defensive explanation and unsupported reassurance. Other patterns receive partial or defensive consequence categories.

**Boundary:** Free text is not automatically judged. Feedback and consequences use marked details and authored components/order; the learner confirms edited prose preserves that intent. Label this assisted response practice.

## Screen 05 — Maya’s response

Show the learner’s committed response and Maya’s authored reaction. Strong recognition makes her more receptive; explanation/reassurance invites a redirect to impact; partial recognition leaves her concerned. Optional coaching explains the component pattern. The committed response is read-only when revisited.

## Screen 06 — Investigate the concern

**Layout:** The wide room fills the slide, with Maya at the right and the current dialogue at the left. Two follow-up prompts appear at a time; Other questions cycles available prompts without changing eligibility. The green notebook scene object opens the concern notebook; the papers open support history. The complete transcript opens as a layer. The current reply replaces the prior reply on stage; the transcript preserves all turns.

**Inquiry:** Initial prompts explore symptoms, planning-time impact, prior attempts, and district rationale. Asking about prior attempts unlocks a communication follow-up. Asking about impact unlocks a team-priority follow-up. Asking about symptoms unlocks a workaround follow-up. Each available prompt is used once; there is no arbitrary overall question limit.

**Findings:** The system would not load shared planning materials; teachers lost shared preparation time; prior requests did not yield dependable updates; Maya wants a named person and timely communication while the issue remains open.

**Notebook action:** Drag revealed evidence into issue, impact, and need, or use the equivalent assignment buttons. Any revealed finding can be placed in a field, allowing meaningful misclassification. The filled-field count indicates work progress, not correctness. Reading the exhibit alone adds no evidence.

**Commit:** At least one inquiry turn and three populated notebook fields enable Confirm summary. The summary may be incomplete or misassigned; Maya’s confirmation supplies the consequence.

## Screen 07 — Confirm understanding

Show the submitted issue, impact, and need. Maya confirms a complete summary, flags a missing communication need, or explains that the summary misses the concern. Ask more / revise summary returns to inquiry while no plan has been committed. Revising the notebook requires reconfirmation before the plan. Maya’s feedback does not automatically fill the notebook.

## Screen 08 — Build the next step

**Scenario authority:** Fictional Tuesday, 10 a.m. The leader can contact support, document impact, and own an update by the next business day. They cannot guarantee a fix or suspend district requirements.

**Plan presentation:** Five states: Owner, Action, Time, If unresolved, Deliver. Open a follow-up record work layer over the dimmed room. Drag an option into its highlighted matching field, or select it to place. All placed commitments remain visible in the record; cards cannot be dropped into a different field type. State tabs allow revision before commitment. Deliver previews the spoken plan beside Maya. Optional wording refinement opens a layer and requires self-review.

**Commit:** All four fields must be selected before Make commitment. Completeness alone does not establish reliability. The plan’s fields drive Maya’s response.

## Screen 09 — Maya’s challenge / repair loop

A safe plan receives a request for dependable follow-through. An unreliable plan receives a specific question about authority, ownership, update timing, communication if unresolved, or instructional impact.

Correct my commitment returns to the builder with an explicit retraction and the original plan retained. Learners can revise and deliver a correction, or keep the original plan. Repaired success leads to Issue Stabilized rather than first-attempt Partnership Restored. Repeated repairs remain possible and are counted transparently.

## Screen 10 — Outcome

Display one ending based on the work products: Partnership Restored, Issue Stabilized, or Concern Escalates. Escalation is a legitimate route for seeking resolution. The numerical v0.2 trust/risk model is retired; current conditions are in the Branching and Assessment Map.

## Screen 11 — Review your work

Use a separate presentation master with the actual work on a paper surface and a coaching annotation across from it. Three sequential debrief components show the learner’s actual opening, notebook summary, and final plan. The plan component also shows the original commitment if repaired. Feedback identifies selected-component and field evidence; edited prose is labeled self-reviewed.

A successful ending plus reviewing all three components earns completion. An escalated attempt remains available for review and replay without successful completion.

## Screen 12 — Take it into practice

Offer an optional action reflection and download of the conversation-preparation sheet. The download includes the opening, summary, final plan, original plan if repaired, outcome, and optional reflection. Reflection is not persisted; task work and progress remain in browser storage. Replay resets the attempt while retaining previously earned completion. Finish displays a completion or attempt-reviewed message.

## Portfolio evidence

Preserve v0.5 and v0.6 before/after screenshots, attributed reference research, the visual development walkthrough, this storyboard, the inquiry map, new assessment rules, synthetic state matrix, actual work outputs, recovery evidence, and browser QA. No learner-effectiveness or district-implementation claim is made.
