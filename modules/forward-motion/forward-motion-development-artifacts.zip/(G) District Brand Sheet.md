# (G) District Brand Sheet — Course Application

Version 0.2 · October 6, 2026 · Source-backed specification; visual board pending

## Source references

- District approved colors (local source reference) — rendered and read.
- District typography, page 17 (local source reference) — rendered and read.
- Logo usage, page 13 (local source reference) — rendered and visually reviewed.
- District logo directory (local source reference) — selected LD District logo.png, visually reviewed and copied without alteration.

These are supplied local reference files. Their current official status has not been confirmed with the district.

## Documented palette

| Role in source | Color | Hex | Course use |
|---|---|---|---|
| Primary | Kelly green | #26A64A | Brand accents, progress accents, selected borders |
| Primary | White | #FFFFFF | Main surface and spacious layout |
| Accent | Black | #000000 | Body text and strong headings |
| Accent | Secondary green | #65C467 | Decorative supporting accents |
| Accent | Gray | #ABABAB | Nonessential dividers and background accents |

The gray source lists RGB 217/217/217, which corresponds to #D9D9D9, alongside hex #ABABAB. Treat this as a source discrepancy. The printed hex is provisional; do not claim the conflict is resolved.

## Typography

The district-use section specifies **Helvetica Neue on Mac or Arial on Windows**, bold for headlines and regular for body. Use Arial as the proposed browser course font.

The central-office section specifies ADAM.CG Pro Regular for graphics and the Communications Team, with a script accent typeface. Those special fonts are not necessary for the proposed course. The accessible interface should rely on the documented district-use family.

## Corporate course direction — proposed

Use a white canvas, black text, measured green accents, generous spacing, and restrained borders. Proposed layout is 16:9 with a compact branded header, a large conversation area, a clearly separated response panel, and a consistent bottom navigation bar. Use Listen → Understand → Act for scenario progress. Hide numerical trust and risk during practice.

Use an existing district mark without recreating it through AI. Character and room visuals can be generated; logos, readable dialogue, buttons, and captions must remain exact editable elements in the authoring tool. The asset-tool constraint is interpreted as applying to generated scenario media; confirm if the user intends otherwise.

Avoid placing ordinary white text on Kelly green without a contrast check. Use black text on the documented green for proposed action buttons. Contrast values and final control treatment will be recorded during prototype QA.

## Portfolio context

Use “Portfolio mockup · fictional scenario” in the case-study introduction and entry screen context. Use district branding with fidelity without claiming endorsement. Preserve source assets separately from course derivatives.

## Prototype logo use

The supplied LD District logo.png is used as an image with its aspect ratio preserved, on the neutral header surface. The reviewed logo-misuse page prohibits stretching, recoloring, cropping, overlays, added effects, and enclosing shapes. The course does not regenerate or alter the mark.


## v0.6 presentation application

The supplied district logo stays unaltered. #26A64A remains the source primary green; Arial/Helvetica provide the source-backed type roles. #164C2B is a derived dark green used for readable player controls, dialogue names, and annotation rules; it is a project UI treatment, not an additional official district color. Room upholstery is photographic context, not brand authority. No logo or district text was generated into the scene photographs.
