# (G) Branching and Assessment Map

Version 0.3 · October 6, 2026 · Task-based prototype

## Flow

```mermaid
flowchart TD
 OPEN[Concern, role, strategy] --> COMPOSE[Mark details and compose an opening]
 COMPOSE --> RESPONSE[Maya responds to authored intent]
 RESPONSE --> INQUIRY[Ask questions and capture revealed evidence]
 INQUIRY --> SUMMARY[Confirm issue, impact, and need]
 SUMMARY --> REVISE[Ask more / revise]
 REVISE --> INQUIRY
 SUMMARY --> PLAN[Build owner, action, deadline, fallback]
 PLAN --> CHALLENGE[Maya evaluates the commitment]
 CHALLENGE --> REPAIR[Explicitly retract and revise]
 REPAIR --> PLAN
 CHALLENGE --> OUTCOME[Evaluate one ending]
 OUTCOME --> REVIEW[Review actual opening, summary, and plan]
 REVIEW --> TRANSFER[Download preparation sheet / finish]
 TRANSFER --> REPLAY[New attempt; preserve earned completion]
 REPLAY --> COMPOSE
```

## Opening evidence

A strong opening marks effort and impact and uses recognition, effort, and impact before an invitation. Defensive rollout/guidance clauses or unsupported same-day reassurance create the defensive category. Other patterns are partial. These are authored tags and ordering rules, not natural-language evaluation. Edited prose requires self-review and is not automatically scored.

## Inquiry evidence and follow-ups

| Initial inquiry | Revealed finding | Follow-up unlocked |
|---|---|---|
| Symptoms | Issue | Workaround → impact |
| Planning-time impact | Impact | Team priority → impact and need |
| Prior attempts | History | Communication → need |
| District rationale | None; Maya redirects | None |

Only revealed evidence can be assigned. Notebook slots are independently checked against issue, impact, and need. Reading the support-history exhibit or confirmation feedback does not automatically add findings.

## Plan reliability

A reliable plan requires all four:

- The learner owns the follow-up.
- The learner contacts support and documents planning-time impact.
- An update is promised today or tomorrow at 3 p.m., within the fictional role boundary.
- The educator receives a status and next-step update even if unresolved.

A guaranteed fix or exemption is outside the stated role authority. Forwarding alone does not document the impact. The alternatives are deliberately authored for this scenario; these are not universal district procedures.

## Mutually exclusive endings

Evaluate in order:

1. Unreliable final plan or a notebook that does not correctly establish both issue and impact → Concern Escalates.
2. Otherwise, strong opening + all three correctly captured notebook fields + reliable first plan with no repair → Partnership Restored.
3. Otherwise → Issue Stabilized.

A safe repaired plan can stabilize a sufficiently understood concern. It does not erase the original promise or demonstrate first-attempt mastery. Numerical v0.2 trust/risk scores are retired.

## Completion and state

Three reviewed debrief components plus a successful ending earn completion. Replay resets marked phrases, assembled wording, inquiry, notebook, plan, and debrief; previously earned completion remains. A committed opening and completed plan are read-only on ordinary revisit. Plan repair is explicit. Revising the notebook invalidates confirmation and relocks subsequent work until reconfirmed.

Progress, draft task work, and final work save under a version-specific local key. v0.2 state is not interpreted as v0.3 work. Optional final reflection is not saved. There is no LMS or server reporting.

## Verification matrix

The State Matrix CSV covers 3 representative opening categories × 8 notebook correctness patterns × 144 owner/action/deadline/fallback configurations = 3,456 synthetic cases. Additional checks cover editing/self-review, ordering, question prerequisites, duplicate questions, invalid evidence, summary revision, repair, resume, and replay.

The matrix checks these defined categories and plan configurations. It is not an exhaustive enumeration of every prose edit, clause subset/permutation, or possible inquiry history. Synthetic ending counts are coverage data, not predicted learner success rates. The former 27 A/B/C routes belong only to archived v0.2.
