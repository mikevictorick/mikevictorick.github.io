# (G) Project Brief

Version 0.6 · October 7, 2026 · Approved browser experience; audio and pilot pending

## Project

**From Frustration to Forward Motion: Responding to an Upset Educator**

Deliver a standalone browser course with Storyline-style mechanics and a portfolio presentation of its development. The finished experience will use Lake Dallas ISD district branding, a restrained corporate presentation, an in-person meeting, AI-created scenario visuals, and ElevenLabs dialogue. The user does not have Storyline; no .story file or Storyline installation is required.

## Performance problem

District leaders may know support procedures but respond defensively, troubleshoot too early, or make promises beyond their authority when an educator expresses frustration. The scenario rehearses what a leader says and does during that conversation.

The educator and operational incident are fictional. Maya Rivera describes repeated failures in an unnamed instructional system and the resulting loss of planning time. The course makes no claim that this occurred at Lake Dallas HS.

## Audience and objective

School district leaders who support educators. Given an emotionally charged educator concern, construct responses that acknowledge the experience, clarify the underlying concern, and establish a realistic next step.

Observable behaviors:

- Acknowledge the impact before explaining process.
- Clarify the problem before proposing a solution.
- Name an owner, action, and update time without guaranteeing an outcome outside the leader’s control.

## Learning experience

Target duration: approximately 15 minutes including reading, decisions, debrief, and reflection. The existing short script alone does not establish a 15-minute experience. Pilot timing will determine whether to adjust the estimate or expand meaningful practice. Do not force waiting to reach the target.

| Phase | Target time | Learner activity |
|---|---|---|
| Why | 1.5 minutes | Hear Maya’s concern and establish the learner’s role |
| What | 1.5 minutes | Explore Acknowledge, Clarify, Commit |
| So What | 8.5 minutes | Compose an opening, investigate and capture evidence, build and repair a follow-up plan |
| Now What | 2 minutes | Interpret the ending and review personalized feedback |
| Reflect | 1.5 minutes | Select or write a workplace commitment |

## Assessment and completion

Reaching Partnership Restored or Issue Stabilized and viewing the complete debrief qualifies for successful completion. Concern Escalates leads to a repair debrief and a retry invitation. Reflection is offered as transfer support; it does not require personal disclosure and is not an additional pass condition.

An unreliable final plan or insufficient issue/impact diagnosis leads to Concern Escalates. Safe repair can lead to Issue Stabilized. Authored component/field rules drive consequences; edited prose is self-reviewed. These are scenario design rules, not validated predictors of real educator trust.

## Delivery and evidence

- Editable HTML/CSS/JavaScript source: verify branching and player behavior in a real browser.
- Published playable course: verify separately from the source project.
- Portfolio artifacts: brief, district brand sheet, storyboard, branch map, character reference sheets, rationale, prompt revisions, QA evidence, and case study.
- Any LMS package/reporting: optional scope decision; browser testing does not establish LMS reporting.
- Case study metrics: label planned measures as proposed; report actual sample size and results if learner testing occurs.

## Accessibility requirements

Provide all spoken dialogue as accessible text; narration is optional, with pause/replay and captions for video. Decisions are untimed. Ensure logical focus order, keyboard access, visible focus, sufficient contrast, and text labels in addition to color. Offer a text alternative to character video. Confirm accessibility in the published output, including a screen-reader check; screenshots cannot establish it.

## v0.3 interaction revision

The user approved replacing the three multiple-choice screens with a response composer, inquiry/evidence notebook, and follow-up plan builder with repair. The debrief and preparation download now use the learner’s actual work products. See the revised Storyboard and Branching Map.


## v0.6 visual direction

The approved research lock uses wide photographic meeting scenes, learner-paced entry, contextual notebook/history objects, and distinct presentation/work/debrief masters. Six wide ChatGPT image states are integrated. Dragging has button alternatives. The visual Development Walkthrough records storyboard, brand and character development, rationale, before/after evidence, and testing. Audio and public delivery remain separate production steps.
