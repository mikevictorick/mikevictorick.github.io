# (G) Design Decision Log

Version 0.3 · October 6, 2026

This record documents rationale, alternatives, constraints, and review decisions. It is not a claim to reproduce private internal reasoning or user research that has not occurred.

| ID | Decision or proposal | Rationale | Evidence and status |
|---|---|---|---|
| D01 | In-person meeting; district branding; corporate feel | Match the user’s intended workplace and portfolio context | User direction; confirmed |
| D02 | Standalone browser course plus portfolio artifacts | Show both authoring capability and development process | User direction; confirmed goal; browser delivery clarified October 6 |
| D03 | Fictional unnamed instructional system | Practice communication without inventing an actual district incident | Supplied scenario; proposed wording |
| D04 | Arial, white canvas, documented green | Use district-use typography and source palette | Supplied brand PDFs, visually reviewed |
| D05 | Three decisions with reconvergence | Keep consequences meaningful while limiting production complexity | Supplied brief; retained |
| D06 | Evaluate outcomes in priority order | Eliminate overlapping and missing ending assignments | Enumeration of 27 paths; checked |
| D07 | Normalize risk at ending only | Handle negative final risk while preserving the supplied arithmetic | Proposed rule; recorded in CSV |
| D08 | Final unsupported promise forces escalation | Prevent a passing ending that rewards an unrealistic final commitment | AAC weakness identified; proposal awaiting review |
| D09 | Conditional recovery before final decision | Every path needs a legitimate impact summary; earlier guarantees need retraction | Revised storyboard; not learner-tested |
| D10 | Scores hidden during conversation | Encourage attention to the exchange rather than point optimization | Supplied brief; retained |
| D11 | Editable native HTML text, controls, and supplied logo | Preserve readability, accessibility, exact branding, and editability | Proposed interpretation of media tools restriction |
| D12 | Fifteen-minute estimate requires a pilot | Short dialogue and three choices may take substantially less time | Timing not tested |
| D13 | Outcome measures remain proposed | A portfolio simulation cannot establish workplace results | Evidence boundary; confirmed documentation practice |

## Review history

- October 6: user approved inclusion of development artifacts and responded “Perfect” to the proposed workflow.
- October 6: planning package created; outstanding production/style questions sent separately.
- No learner review, SME validation, or generated asset comparison has occurred. Functional browser QA is recorded separately.

## Record future changes

For each actual review: date, reviewer role, artifact/version, observed issue, revision, and verification. Preserve before/after screenshots only when real versions exist. Do not manufacture rejected alternatives to make the process appear more elaborate.

## Delivery correction — October 6

The user clarified that they do not have Storyline and want a course with comparable mechanics and style. Deliver a standalone browser course; do not claim native Articulate authoring. Version 0.1 planning documents are preserved in Development History.

## Prototype refinement — October 6

- The first desktop render expanded to fit the 15-item menu. A fixed desktop slide area and independently scrolling menu were added to preserve the intended player proportions. A before-refinement screenshot is preserved in Development History/v0.2 Before QA.
- Browser keyboard QA found Tab leaving a Resources overlay with one focusable control. An explicit focus loop was added; the repeated browser check passed.
- Notes changed from concatenated plain text to separated readable blocks.
- A page favicon was added to eliminate the initial local-server favicon 404.

## Approved interaction redesign — October 6

The user requested richer interactions and approved the proposal. Replaced the three selected-response decisions with response construction, branching inquiry and evidence capture, and commitment planning with repair. Retired v0.2 numerical scoring; preserved the earlier browser prototype, documents, and evidence in Development History/v0.2 Browser Prototype.

The new debrief shows real work products. Edited prose is explicitly self-reviewed, while authored tags/fields determine consequences. A repaired safe commitment can stabilize the issue but cannot claim first-attempt partnership.

Visual QA shortened clipped dropdown labels and preserved the latest conversation-scroll position during notebook assignments. Before-refinement images are retained as real revision evidence.

## October 6, 2026 — v0.4 slide presentation

User feedback: v0.3 looked closer to Rise 360. User approved the proposed slide-stage revision before implementation. Archived the complete v0.3 source, output, and artifacts. Replaced scrolling task workspaces with short object states and focused layers; kept assessment and recovery rules. Used a fixed 16:9 desktop stage with an overlay menu to preserve geometry. Phone layouts adapt for readability. Verified three representative outcomes, 25 task-width checks, and 60 desktop slide-state fits. Media generation remains pending approval.

## October 7 — ChatGPT image review batch

User excluded Higgsfield for images and selected ChatGPT. Generated Maya’s six-angle identity sheet, then a seated meeting still using that sheet as a reference. Saved both original-resolution outputs and exact prompts in Media Production/Review Batch 01. Visual review: identity and wardrobe appear consistent; the meeting expression is restrained and concerned, and a pen was added. User approval and expression variants remain pending. No course integration yet.

## October 7 — Approved expression production and integration

User approved Maya and room. Produced six reference-based ChatGPT edits with restrained professional emotion. Kept original PNGs, exact prompts, JPEG course exports, a labeled HTML expression sheet, and state mapping. Archived v0.4 before adding media. The same room serves every scene; no additional environment generation was needed. Course v0.5 embeds stills in the portable file. Voice remains pending.


## October 7, 2026 — v0.6 researched scene rebuild

User approved the reference combination after clarifying presentation-style Storyline. Conversations That Work informed the photographic meeting composition and dialogue; Office Scavenger Hunt informed clickable notebook/paper objects; Call Center Crisis informed distinct slide families and paced entry. Third-party screenshots stay attributed research evidence, separate from original project assets.

Replaced portrait panels with six wide room states. Added paced entry, numbered strategy reveals with visited states, paper response/follow-up layers, scene-object access, native clause/evidence/plan dragging with button equivalents, and an annotated actual-work debrief. Saved presentation substates alongside compatible task state. Kept the assessment engine unchanged.

Visual rationale: a stable eye-level room grounds the learner in the meeting; Maya's position leaves usable dialogue space; work layers temporarily focus attention; briefing and debrief masters give the experience authored slide variation. Natural restrained expressions avoid exaggerated emotional shorthand. The build is original browser implementation, not a copied template or native Storyline project.

Refinement: removed duplicate notebook access from the dialogue panel so the scene object owns that action. Browser drag checks distinguish insertion onto a clause from appending into blank response space. Portfolio captures finish entrance animations before capture.

Small-window refinement: summary content clipped at an 820-pixel viewport during the extra fit pass. Expanded the adaptive breakpoint to 1000 pixels and checked 40 substates at 820 and 900 pixels successfully. The fixed 16:9 stage remains above that breakpoint.
