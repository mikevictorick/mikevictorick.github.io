# (G) Character and Asset Specifications

Version 0.5 · October 7, 2026 · Approved identity and generated still set

## Proposed cast and perspective

Maya Rivera is a fictional educator, not a likeness of a Lake Dallas employee. She is a credible professional with a legitimate operational concern. Do not infer ethnicity from her surname. Approved appearance: early 40s, shoulder-length dark brown hair, charcoal blazer and ivory blouse. Voice remains pending.

The learner is an unseen district leader seated across a conference table. An unseen leader limits unnecessary character generation and keeps the response choice in the learner’s voice. The approved seated scene uses this perspective.

## Character sheet deliverables

1. Identity sheet: six large close-up portraits with front, three-quarter left, left profile, front anchor, three-quarter right, and right profile views.
2. Expression sheet: frustrated but composed; guarded; listened-to; cautiously reassured; unresolved; disengaged. Preserve facial identity and avoid caricature.
3. Wardrobe/scene reference: seated upper-body view, stable clothing and accessories, consistent posture and room lighting.

For each sheet, keep an approved image identifier, tool/model, exact prompt, date, dimensions, revision, and selection reason. The identity sheet and labeled expression sheet are now retained in Media Production.

## Environment reference

A fictional school conference room, not a claimed depiction of an actual Lake Dallas room. Eye-level perspective across the table; uncluttered neutral setting; soft practical lighting; enough clear space for readable editable dialogue outside the image. Do not generate school signage or district marks inside the scene.

## Asset inventory

| ID | Asset | Planned use | Status |
|---|---|---|---|
| BR-01 | Supplied district logo | Header and entry screen | Supplied district logo selected; used unaltered |
| CH-01 | Maya identity sheet | Continuity anchor | Generated and approved |
| CH-02 | Maya expression sheet | Consequence states | Six generated variants; integrated |
| ENV-01 | Conference-room reference | Scene continuity | Approved seated still is the room reference |
| SC-01 | Opening still or clip | Cold open | Generated still integrated |
| SC-02–07 | Consequence expression states | Decisions and endings | Six expression states integrated |
| VO-01 | Maya dialogue | ElevenLabs audio | Voice pending |
| VO-02 | Optional orientation/debrief voice | Accessible coaching | Scope pending |
| UI-01 | Editable response controls and captions | Course navigation | Editable browser controls implemented |

## Tool boundaries

The user excluded Higgsfield for images and selected ChatGPT on October 7. The built-in ChatGPT image tool produced all current character images. Midjourney or Google remain possible future image routes if requested. ElevenLabs is the planned voice provider. No provider substitution or specific unreported model version is claimed.

## Skool references consulted

- Character Lab / Character Sheets / “Character Consistency: Sheet Prompt”: large unobstructed facial views and preservation of asymmetry.
- Video Lab / “Seedance - Global Lock System”: reusable identity, environment, and visual-treatment declarations.
- AI Cinema & Storyboards / “Database: Storyboard, Reference Images Prompts”: points to an external storyboard database, whose contents were not inspected.

Apply the local reference concepts as prompt-writing guidance. Do not treat lesson claims as verified guarantees of model behavior. Test continuity visually on actual outputs. No external database content is assumed.

## Approval checks before generation

Character identity, photographic style, and room direction were approved before expression production. Voice approval is a separate pending step. Inspect facial continuity, wardrobe, emotion, composition, and space for editable UI. Log real revisions and selected outputs for the portfolio.


## v0.6 wide scene production

Approved presentation rebuild produced a wide master using the approved Maya meeting still as the identity and room reference. Five expression edits lock the master framing, wardrobe, hands/pen, room, notebook, papers, perspective, and lighting. Maya sits at the right; the left supports authored dialogue. The tabletop notebook and papers provide scene-object affordances.

Full PNG originals and exact prompts are in Media Production/Wide Scene Set 01. Six JPEG exports in Course Source/assets use `maya-wide-{state}.jpg`; the portable build embeds them. Generated wide images are 1672 × 941, closely matching 16:9; object-fit covers the stage. Mapping: frustrated (entry/opening), guarded (weak opening or unreliable commitment), receptive (strong opening/inquiry/summary), waiting (plan/safe commitment/stabilized), reassured (restored), unresolved (escalated).

Visual review checked face, hands, wardrobe, table, furniture, and composition continuity. Expression differences remain intentionally restrained. Generated imagery is disclosed in portfolio process evidence; these are fictional scenes, not photographs of district personnel or facilities.
