# (G) SCORM and Web Delivery

v0.9 · October 8, 2026

Upload (G) Forward Motion - scorm-1.2 - v0.9.zip as a SCORM 1.2 course. The ZIP root contains imsmanifest.xml and a self-contained index.html, including all character media and 31 voiceovers. Launch from the LMS rather than opening index.html directly to establish tracking.

Completion is earned after Partnership Restored or Issue Stabilized and the full three-part debrief. Concern Escalates does not earn completion. Replay does not erase an already earned completion. No numeric score is reported.

Resume stores work products, navigation, and presentation state with lossless compression. Data is checked against the SCORM 1.2 4,096-character limit; oversized attempts produce an explicit warning rather than silent truncation. Optional reflection is session-only. LMS review/browse mode does not write progress. Corrupt resume data blocks overwriting. Save and exit commits and closes the LMS session. Browser standalone progress remains separate.

Thirteen automated adapter tests passed. Browser mock-LMS checks passed for initialization, restored work, successful debrief completion, save/finish, and completed-session relaunch. ZIP contents and manifest resource references passed validation. These are preparation for an LMS pilot; actual LMS import/reporting and cross-device resume remain unverified.

Pilot: import the ZIP; launch as a learner; save midway; relaunch and verify work and navigation; finish a qualifying ending and debrief; inspect completion in LMS reports; retry and confirm prior completion remains; check review mode and target-device audio.
